# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

